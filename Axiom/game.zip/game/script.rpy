﻿define b = Character("小黑兔")
define e = Character("以利亚")

image room1 = Transform("room1.png", zoom=0.75)
image b = Transform("b.png", zoom=0.75)

# 游戏在此开始。

label start:
    scene room1
    show e1
    e "为什么我身体动不了了，好疼（躺在地上奄奄一息）"
    e "（意识模糊）"
    hide e1
    with fade  # 视觉上给人一种“意识模糊后重连”的感觉
    show b
    b "以利亚，你终于醒来了，这是你死亡的前 1 秒"
    b "请集中注意力，现在要开始新的旅程了..（记住你只有一次回到过去的机会）"
    with pixellate # 使用像素化转场表示进入回忆
    b "以利亚，现在这是你死亡的前 20 秒"
    with pixellate
    b "以利亚，现在这是你死亡的前 35 秒！之后的时间距离你的出生之日不断缩短"
    hide b
    with fade
    show e2
    e "（意识模糊）"

    # 开始选择
    menu:
        "现在你面临一个选择.."
        "还没有准备好":
            b "意识陷入模糊"
            return

        "我准备好了……":
            hide e2
            with fade
            show b
            b "时间不等人。我们开始吧"
            jump go_next

label go_next:
    hide b 
    menu:
        "由于身体还没有完全恢复..." 
        "装死":
            "现在等待了 100 秒时间，感觉又年轻了。"

        "大声呼救":
            with fade
            "原来你现在的处境非常危险，是一名被害者，才导致如此下场"
            "你被彻底杀死了。"




# 此处为游戏结尾。
return
